cmake_minimum_required(VERSION 3.20)
project(CellularGA 
        VERSION 0.1.0
				DESCRIPTION "kFLS on Frequency Assignment Problems"
        LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

set(COMMON_WARNINGS "-Wall -Wextra -Werror -Wpedantic -Wconversion -Wshadow")

set(COMMON_CXX_FLAGS "${COMMON_WARNINGS} -march=native")

set(CMAKE_CXX_FLAGS_RELEASE "-O3 -flto -DNDEBUG ${COMMON_CXX_FLAGS}")

set(CMAKE_CXX_FLAGS_DEBUG "-O0 -g -fsanitize=address,undefined ${COMMON_CXX_FLAGS}")

# set(THREADS_PREFER_PTHREAD_FLAG ON)

add_subdirectory(src)
